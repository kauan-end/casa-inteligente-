# Painel da Casa Inteligente

Painel em **Flask** que simula o controle de uma casa inteligente (projeto 12 da disciplina PSI129A – Conectividade em Sistemas Ciberfísicos). Ele roda em Linux/WSL 2 e expõe uma API HTTP para consultar o estado da casa e enviar comandos a dispositivos, com autenticação por token, validação de entradas, concorrência por threads e registro de logs.

## O que o painel faz

- **Consulta o estado da casa** (`GET /status`): temperatura, lâmpada da sala e alarme.
- **Recebe comandos** (`POST /comando`): liga/desliga a lâmpada e ativa/desativa o alarme.
- **Exige token** no cabeçalho `Authorization: Bearer <token>`. Sem token ou com token errado, responde `401`.
- **Valida as entradas** e devolve o código HTTP adequado para cada erro.
- **Atende vários clientes ao mesmo tempo** (`threaded=True`), com `threading.Lock` protegendo o estado compartilhado.
- **Registra logs** em arquivo, com data, nível, nome da thread e mensagem.

> O estado da casa fica em memória e a temperatura é fixa (simulação). Os dados voltam ao padrão quando o servidor é reiniciado.

## Dependências

- Python 3.8 ou superior
- Flask

Bibliotecas padrão usadas: `logging`, `os`, `threading`.

| Biblioteca | Função | Justificativa |
|---|---|---|
| `Flask` | Servidor web e rotas HTTP | Simples, leve e adequada para uma API pequena |
| `logging` | Logs em arquivo | Evidência de funcionamento e diagnóstico |
| `threading` | `Lock` para proteger o estado | Evita condição de corrida entre requisições simultâneas |
| `os` | Leitura de variáveis de ambiente | Configurar token e arquivo de log sem editar o código |

## Instalação

```bash
# 1. Entre na pasta do projeto
cd trabalho_sistema

# 2. (Recomendado) crie e ative um ambiente virtual
python3 -m venv venv
source venv/bin/activate

# 3. Instale o Flask
pip install flask
```

Se o `pip` reclamar de "externally managed environment", use o ambiente virtual acima.

## Variáveis de ambiente

| Variável | Obrigatória | Padrão | Descrição |
|---|---|---|---|
| `PAINEL_API_TOKEN` | Recomendada | `token_da_casa_123` | Token que o cliente deve enviar no cabeçalho `Authorization` |
| `PAINEL_LOG_FILE` | Não | `painel_casa.log` | Caminho do arquivo de log |

Exemplo:

```bash
export PAINEL_API_TOKEN="troque_este_token"
export PAINEL_LOG_FILE="painel_casa.log"
```

**Importante:** o valor padrão do token existe só para facilitar testes. Em uso real, defina sempre o seu próprio `PAINEL_API_TOKEN` e não publique tokens no repositório.

## Como subir o servidor

```bash
export PAINEL_API_TOKEN="token_da_casa_123"
python painel.py
```

(No Linux, se `python` não funcionar, use `python3 painel.py`.)

O servidor sobe na porta **5000** e aceita conexões de outras máquinas (`host=0.0.0.0`). Acesse por `http://localhost:5000` ou pelo IP da máquina na rede, por exemplo `http://192.168.25.20:5000`.

Para conferir se está escutando:

```bash
ss -tlnp | grep 5000
```

Para acompanhar o log em tempo real:

```bash
tail -f painel_casa.log
```

Recomendação de segurança (mínimo privilégio): rode o painel com um usuário sem privilégios de administrador e restrinja o arquivo de log:

```bash
chmod 640 painel_casa.log
```

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
| GET | `/status` | Retorna o estado atual da casa |
| POST | `/comando` | Altera o estado de um dispositivo |

### Corpo do `POST /comando`

```json
{"dispositivo": "lampada_sala", "acao": "ligada"}
```

Ações permitidas:

| Dispositivo | Ações |
|---|---|
| `lampada_sala` | `ligada`, `desligada` |
| `alarme` | `ativado`, `desativado` |

A `temperatura` é leitura de sensor e não aceita comando.

### Códigos de resposta

| Código | Quando acontece |
|---|---|
| 200 | Requisição bem-sucedida |
| 400 | Corpo ausente ou JSON inválido |
| 401 | Token ausente ou inválido |
| 404 | Dispositivo inexistente |
| 422 | Campo faltando ou ação inválida para o dispositivo |
| 500 | Erro interno inesperado |

## Testes com `curl`

Com o servidor rodando, abra outro terminal. Os exemplos usam o token padrão; troque pelo seu, se tiver definido outro.

### 1. Consultar o status com token válido (esperado: 200)

```bash
curl -i -H "Authorization: Bearer token_da_casa_123" http://localhost:5000/status
```

Resposta esperada:

```json
{"alarme":"ativado","lampada_sala":"desligada","temperatura":22.5}
```

### 2. Token inválido (esperado: 401)

```bash
curl -i -H "Authorization: Bearer token_errado" http://localhost:5000/status
```

Resposta esperada:

```
HTTP/1.1 401 UNAUTHORIZED
{"erro":"Nao autorizado"}
```

No log aparece um aviso com o IP de origem:

```
[WARNING] ... - Token invalido de 127.0.0.1
```

### 3. Sem token (esperado: 401)

```bash
curl -i http://localhost:5000/status
```

### 4. Ligar a lâmpada (esperado: 200)

```bash
curl -i -X POST http://localhost:5000/comando \
  -H "Authorization: Bearer token_da_casa_123" \
  -H "Content-Type: application/json" \
  -d '{"dispositivo":"lampada_sala","acao":"ligada"}'
```

Confirme com o `GET /status` do teste 1: `lampada_sala` deve aparecer como `ligada`.

### 5. JSON inválido (esperado: 400)

```bash
curl -i -X POST http://localhost:5000/comando \
  -H "Authorization: Bearer token_da_casa_123" \
  -H "Content-Type: application/json" \
  -d 'isto nao e json'
```

### 6. Campo faltando (esperado: 422)

```bash
curl -i -X POST http://localhost:5000/comando \
  -H "Authorization: Bearer token_da_casa_123" \
  -H "Content-Type: application/json" \
  -d '{"dispositivo":"lampada_sala"}'
```

### 7. Dispositivo inexistente (esperado: 404)

```bash
curl -i -X POST http://localhost:5000/comando \
  -H "Authorization: Bearer token_da_casa_123" \
  -H "Content-Type: application/json" \
  -d '{"dispositivo":"garagem","acao":"ligada"}'
```

### 8. Ação inválida (esperado: 422)

```bash
curl -i -X POST http://localhost:5000/comando \
  -H "Authorization: Bearer token_da_casa_123" \
  -H "Content-Type: application/json" \
  -d '{"dispositivo":"lampada_sala","acao":"banana"}'
```

### 9. Vários clientes ao mesmo tempo

Dispara 20 requisições, até 10 em paralelo:

```bash
seq 20 | xargs -P 10 -I{} curl -s -o /dev/null -w "%{http_code}\n" \
  -H "Authorization: Bearer token_da_casa_123" http://localhost:5000/status
```

Todas devem retornar `200`. No `painel_casa.log`, o campo `threadName` mostra threads diferentes atendendo as requisições.

## Resumo dos testes

| ID | Teste | Esperado |
|---|---|---|
| T01 | `GET /status` com token válido | 200 |
| T02 | `GET /status` com token inválido | 401 |
| T03 | `GET /status` sem token | 401 |
| T04 | `POST /comando` ligando a lâmpada | 200 |
| T05 | `POST /comando` com JSON inválido | 400 |
| T06 | `POST /comando` com campo faltando | 422 |
| T07 | `POST /comando` com dispositivo inexistente | 404 |
| T08 | `POST /comando` com ação inválida | 422 |
| T09 | 20 requisições em paralelo | todas 200 |

## Problemas comuns

- **Porta em uso:** outro processo já usa a 5000. Veja com `ss -tlnp | grep 5000` e encerre o processo, ou altere a porta no final do `painel.py`.
- **Outra máquina não acessa o painel:** confira se o servidor está com `host="0.0.0.0"`, se o IP está correto e se o firewall (`ufw`) libera a porta: `sudo ufw allow 5000/tcp`.
- **Sempre dá 401:** confira se o token do cabeçalho é igual ao `PAINEL_API_TOKEN` do servidor e se o formato é `Authorization: Bearer <token>`.
- **Verificar a sintaxe do arquivo:** `python -m py_compile painel.py`.
